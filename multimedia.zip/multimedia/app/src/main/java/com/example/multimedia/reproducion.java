package com.example.multimedia;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class reproducion {


    public class MainActivity extends AppCompatActivity {

        private List<String> profiles = new ArrayList<>();
        private RecyclerView recyclerView;
        private ProfileAdapter adapter;
        private MediaPlayer mediaPlayer;
        private boolean isPaused = false;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            profiles.add("Usuario 1");
            profiles.add("Usuario 2");
            profiles.add("Usuario 3");

            recyclerView = findViewById(R.id.profileRecyclerView);
            recyclerView.setLayoutManager(new LinearLayoutManager(this));
            adapter = new ProfileAdapter(profiles);
            recyclerView.setAdapter(adapter);

            Button btnSelectUser = findViewById(R.id.btnSelectUser);
            btnSelectUser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSelectUserDialog();
                }

                private void showSelectUserDialog() {
                }
            });

            Button btnAddProfile = findViewById(R.id.btnAddProfile);
            btnAddProfile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showAddProfileDialog();
                }

                private void showAddProfileDialog() {
                }
            });

            // reproducción del audio
            mediaPlayer = MediaPlayer.create(this, R.raw.intro_audio);
            Button btnPause = findViewById(R.id.btnPause);
            btnPause.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                        isPaused = true;
                    }
                }
            });

            Button btnContinue = findViewById(R.id.btnContinue);
            btnContinue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isPaused) {
                        mediaPlayer.start();
                        isPaused = false;
                    }
                }
            });
        }


    }

}
