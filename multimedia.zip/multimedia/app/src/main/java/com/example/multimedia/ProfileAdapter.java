package com.example.multimedia;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;




        public class ProfileAdapter extends RecyclerView.Adapter<ProfileAdapter.ProfileViewHolder> {

            private List<String> profiles;

            public ProfileAdapter(List<String> profiles) {
                this.profiles = profiles;
            }

            @NonNull
            @Override
            public ProfileViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_categoria, parent, false);
                return new ProfileViewHolder(view);
            }

            @Override
            public void onBindViewHolder(@NonNull ProfileViewHolder holder, int position) {
                String profileName = profiles.get(position);
                holder.txtProfileName.setText(profileName);
            }

            @Override
            public int getItemCount() {
                return profiles.size();
            }

            static class ProfileViewHolder extends RecyclerView.ViewHolder {
                TextView txtProfileName;

                public ProfileViewHolder(@NonNull View itemView) {
                    super(itemView);
                    txtProfileName = itemView.findViewById(R.id.txtProfileName);
                }
            }
        }


