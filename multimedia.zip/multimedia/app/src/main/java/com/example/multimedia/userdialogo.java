package com.example.multimedia;

import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class userdialogo {


    private void showCategories(String profile) {
        // Agregar aquí la lógica para mostrar las categorías según el perfil seleccionado
        List<String> categories = new ArrayList<>();

        if (profile.equalsIgnoreCase("infantil")) {
            categories.add("Caricaturas");
        } else if (profile.equalsIgnoreCase("adolescentes")) {
            categories.add("Caricaturas");
            categories.add("Acción");
        } else if (profile.equalsIgnoreCase("adultos")) {
            categories.add("Caricaturas");
            categories.add("Acción");
            categories.add("Terror");
        }

        // Mostrar las categorías en la interfaz (RecyclerView o cualquier otro componente)
        // Puedes utilizar un ArrayAdapter o un RecyclerViewAdapter para mostrar las categorías en la lista.
        // Ejemplo con ArrayAdapter:
        ArrayAdapter<String> categoriesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, categories);recyclerView;
        recyclerView.setAdapter(categoriesAdapter);
    }


}
